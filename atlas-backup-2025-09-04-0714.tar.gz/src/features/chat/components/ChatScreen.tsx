// This file has been refactored into smaller components
// See: MessageList.tsx, MessageBubble.tsx, ChatInput.tsx, etc.
export default function ChatScreen() {
  return null; // Placeholder for backward compatibility
}
